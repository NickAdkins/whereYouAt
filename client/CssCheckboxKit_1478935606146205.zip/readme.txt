CSS CHECKBOX - README AND INSTALLATION GUIDE - www.csscheckbox.com
1. Open the included file 'style.css' and copy the CSS code into your own stylesheet
2. Change the classes of your HTML Checkboxes to 'css-checkbox'
3. Change the classes of your HTML Checkbox Labels to 'css-label'
4. MAKE SURE that the ID of your Checkbox matches the FOR attribute of your HTML Label tag
Refer to the included file 'demo.html' for HTML samples and syntax.